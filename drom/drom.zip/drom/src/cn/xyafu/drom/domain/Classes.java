package cn.xyafu.drom.domain;

import java.util.HashSet;
import java.util.Set;

public class Classes {
private String id;//班级ID
private String class_name;//班级名称
private Profession proFession;//专业
private Set<Student> students=new HashSet<Student>();
public String getId() {
	return id;
}
public void setId(String id) {
	this.id = id;
}
public String getClass_name() {
	return class_name;
}
public void setClass_name(String class_name) {
	this.class_name = class_name;
}
public Profession getProFession() {
	return proFession;
}
public void setProFession(Profession proFession) {
	this.proFession = proFession;
}

public Set<Student> getStudents() {
	return students;
}
public void setStudents(Set<Student> students) {
	this.students = students;
}
@Override
public String toString() {
	return "Class [id=" + id + ", class_name=" + class_name + "]";
}

}
