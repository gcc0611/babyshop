package cn.xyafu.drom.domain;

import java.sql.Date;

public class Message {
	private String id;	
	private String m_title;
	private Date create_time;
	private String content;
	private String reply;
	private String rename;
	private Date retime;
	private Student student;
	
	public Student getStudent() {
		return student;
	}
	public void setStudent(Student student) {
		this.student = student;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getM_title() {
		return m_title;
	}
	public void setM_title(String m_title) {
		this.m_title = m_title;
	}
	public Date getCreate_time() {
		return create_time;
	}
	public void setCreate_time(Date create_time) {
		this.create_time = create_time;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getReply() {
		return reply;
	}
	public void setReply(String reply) {
		this.reply = reply;
	}
	public String getRename() {
		return rename;
	}
	public void setRename(String rename) {
		this.rename = rename;
	}
	public Date getRetime() {
		return retime;
	}
	public void setRetime(Date retime) {
		this.retime = retime;
	}
	@Override
	public String toString() {
		return "Message [id=" + id + ", m_title=" + m_title + ", create_time=" + create_time + ", content=" + content
				+ ", reply=" + reply + ", rename=" + rename + ", retime=" + retime + "]";
	}
	
	
	

}
