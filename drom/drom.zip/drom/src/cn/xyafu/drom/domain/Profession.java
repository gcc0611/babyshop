package cn.xyafu.drom.domain;

import java.util.HashSet;
import java.util.Set;

public class Profession {
	private String id;//专业ID
	private String p_name;//专业名
	private College college;//学院
	private Set<Classes> classes=new HashSet<Classes>();//班级
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getP_name() {
		return p_name;
	}
	public void setP_name(String p_name) {
		this.p_name = p_name;
	}
	
	public College getCollege() {
		return college;
	}
	public void setCollege(College college) {
		this.college = college;
	}
	public Set<Classes> getClasses() {
		return classes;
	}
	public void setClasses(Set<Classes> classes) {
		this.classes = classes;
	}
	@Override
	public String toString() {
		return "Profession [id=" + id + ", p_name=" + p_name + "]";
	}
	
}
