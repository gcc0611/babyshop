package cn.xyafu.drom.domain;


public class Admin {
private String id;//管理员ID
private String admin_name;//管理员姓名
private String admin_pwd;//密码

public String getId() {
	return id;
}
public void setId(String id) {
	this.id = id;
}
public String getAdmin_name() {
	return admin_name;
}
public void setAdmin_name(String admin_name) {
	this.admin_name = admin_name;
}
public String getAdmin_pwd() {
	return admin_pwd;
}
public void setAdmin_pwd(String admin_pwd) {
	this.admin_pwd = admin_pwd;
}
@Override
public String toString() {
	return "Admin [id=" + id + ", admin_name=" + admin_name + ", admin_pwd=" + admin_pwd + "]";
}

}
