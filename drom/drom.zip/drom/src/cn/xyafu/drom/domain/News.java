package cn.xyafu.drom.domain;

import java.util.Date;

public class News {
private String id;
private String news_title;
private Date create_time;
public String getId() {
	return id;
}
public void setId(String id) {
	this.id = id;
}

public String getNews_title() {
	return news_title;
}
public void setNews_title(String news_title) {
	this.news_title = news_title;
}
public Date getCreate_time() {
	return create_time;
}
public void setCreate_time(Date create_time) {
	this.create_time = create_time;
}
@Override
public String toString() {
	return "News [id=" + id + ", news_title=" + news_title + ", create_time=" + create_time + "]";
}



}
