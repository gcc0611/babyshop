package cn.xyafu.drom.domain;

public class Billinfo {
private String id; //水电费ID
private String water;//水表数
private String elect;//电表数
private String money;//余额
private Drom drom;
public Drom getDrom() {
	return drom;
}
public void setDrom(Drom drom) {
	this.drom = drom;
}
public String getId() {
	return id;
}
public void setId(String id) {
	this.id = id;
}
public String getWater() {
	return water;
}
public void setWater(String water) {
	this.water = water;
}
public String getElect() {
	return elect;
}
public void setElect(String elect) {
	this.elect = elect;
}
public String getMoney() {
	return money;
}
public void setMoney(String money) {
	this.money = money;
}
@Override
public String toString() {
	return "Billinfo [id=" + id + ", water=" + water + ", elect=" + elect
			+ ", money=" + money + "]";
}
}
