package cn.xyafu.drom.domain;

import java.util.HashSet;
import java.util.Set;

public class Student {
private String id;//学号
private String stu_name;//姓名
private String stu_pwd;//密码
private Integer stu_sex;//性别
private Classes classes;//班级
private Drom drom;
private Set<Message> messages=new HashSet<Message>();
private Set<Repair> repairs=new HashSet<Repair>();

public Set<Repair> getRepairs() {
	return repairs;
}
public void setRepairs(Set<Repair> repairs) {
	this.repairs = repairs;
}
public Drom getDrom() {
	return drom;
}
public void setDrom(Drom drom) {
	this.drom = drom;
}
public Set<Message> getMessages() {
	return messages;
}
public void setMessages(Set<Message> messages) {
	this.messages = messages;
}
public String getId() {
	return id;
}
public void setId(String id) {
	this.id = id;
}
public String getStu_name() {
	return stu_name;
}
public void setStu_name(String stu_name) {
	this.stu_name = stu_name;
}
public String getStu_pwd() {
	return stu_pwd;
}
public void setStu_pwd(String stu_pwd) {
	this.stu_pwd = stu_pwd;
}
public Integer getStu_sex() {
	return stu_sex;
}
public void setStu_sex(Integer stu_sex) {
	this.stu_sex = stu_sex;
}

public Classes getClasses() {
	return classes;
}
public void setClasses(Classes classes) {
	this.classes = classes;
}
@Override
public String toString() {
	return "Student [id=" + id + ", stu_name=" + stu_name + ", stu_pwd=" + stu_pwd + ", stu_sex=" + stu_sex
			+ ", stu_teacher=" +  "]";
}



}
