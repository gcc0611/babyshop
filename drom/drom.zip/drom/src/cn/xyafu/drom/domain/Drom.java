package cn.xyafu.drom.domain;

import java.util.HashSet;
import java.util.Set;

public class Drom {
	private String id;
	private String drom_hao;
	private String drom_sex;
	private Integer drom_count;
	private Billinfo billinfo;
	public Billinfo getBillinfo() {
		return billinfo;
	}
	public void setBillinfo(Billinfo billinfo) {
		this.billinfo = billinfo;
	}
	private Set<Student> students= new HashSet<Student>();
	public Set<Student> getStudents() {
		return students;
	}
	public void setStudents(Set<Student> students) {
		this.students = students;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getDrom_hao() {
		return drom_hao;
	}
	public void setDrom_hao(String drom_hao) {
		this.drom_hao = drom_hao;
	}
	public String getDrom_sex() {
		return drom_sex;
	}
	public void setDrom_sex(String drom_sex) {
		this.drom_sex = drom_sex;
	}
	public Integer getDrom_count() {
		return drom_count;
	}
	public void setDrom_count(Integer drom_count) {
		this.drom_count = drom_count;
	}
	@Override
	public String toString() {
		return "drom [id=" + id + ", drom_hao=" + drom_hao + ", drom_sex=" + drom_sex + ", drom_count=" + drom_count
				+ "]";
	}
	
	
    
}
