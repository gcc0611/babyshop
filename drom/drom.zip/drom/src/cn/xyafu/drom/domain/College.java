package cn.xyafu.drom.domain;

import java.util.HashSet;
import java.util.Set;

public class College {
 private String id;//学院ID
 private String college_name;//学院名
 private Set<Profession> pro=new HashSet<Profession>();//专业
public String getId() {
	return id;
}
public void setId(String id) {
	this.id = id;
}
public String getCollege_name() {
	return college_name;
}
public void setCollege_name(String college_name) {
	this.college_name = college_name;
}

public Set<Profession> getPro() {
	return pro;
}
public void setPro(Set<Profession> pro) {
	this.pro = pro;
}
@Override
public String toString() {
	return "College [id=" + id + ", college_name=" + college_name + "]";
}
 
}
