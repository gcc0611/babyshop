package cn.xyafu.drom.domain;

import java.util.Date;

public class Repair {
private String id;
private String  re_content;
private Date create_time;
private Integer state;
private Student student;
public Student getStudent() {
	return student;
}
public void setStudent(Student student) {
	this.student = student;
}
public String getId() {
	return id;
}
public void setId(String id) {
	this.id = id;
}
public String getRe_content() {
	return re_content;
}
public void setRe_content(String re_content) {
	this.re_content = re_content;
}
public Date getCreate_time() {
	return create_time;
}
public void setCreate_time(Date create_time) {
	this.create_time = create_time;
}
public Integer getState() {
	return state;
}
public void setState(Integer state) {
	this.state = state;
}

@Override
public String toString() {
	return "Repair [id=" + id + ", re_content=" + re_content + ", create_time=" + create_time + ", state=" + state
			+ " ]";
}

}
