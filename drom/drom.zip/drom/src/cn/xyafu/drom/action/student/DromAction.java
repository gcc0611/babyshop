package cn.xyafu.drom.action.student;

import java.util.List;

import com.opensymphony.xwork2.ModelDriven;

import cn.xyafu.drom.action.BaseAction;
import cn.xyafu.drom.domain.Drom;
import cn.xyafu.drom.service.ClassService;
import cn.xyafu.drom.service.DromService;
import cn.xyafu.drom.util.Page;

public class DromAction extends BaseAction implements ModelDriven<Drom>{
	private Drom model=new Drom();
	private ClassService classService;
	private DromService dromService;
	
	  public DromService getDromService() {
		return dromService;
	}
	public void setDromService(DromService dromService) {
		this.dromService = dromService;
	}
	public ClassService getClassService() {
		return classService;
	}
	public void setClassService(ClassService classService) {
		this.classService = classService;
	}
	public Drom getModel() {
			return model;
		}

		//分页组件
		private Page<Drom> page=new Page<Drom>();

		public Page<Drom> getPage() {
			return page;
		}
		public void setPage(Page<Drom> page) {
			this.page = page;
		}
		
		public String list() throws Exception {
			//通过Service查找数据
			String hql="from Drom";
			List<Drom> dromList=dromService.find(hql, Drom.class, null);
			this.put("dromList", dromList);
			return "list";
		}
		public String toview() throws Exception{
			System.out.println(model.getId());
			System.out.println(model.getDrom_hao());
			List<Drom> dromList=dromService.find("from Drom d where d.id='"+model.getId()+"'",Drom.class, null);
			if(dromList!=null&&dromList.size()>0) {
			this.put("dromList",dromList);
			return "toview";
			}else {
				super.put("msg","该用户不存在或账号错误");
				return "toview";
			}
				
		}
	   public String insert() throws Exception{
		   dromService.saveOrUpdate(model);
			return toview();
		}
	   
	   public String tocreate() throws Exception{
//		   List<Class> classList=classService.find("from Class", Class.class, null);
//		   List<Drom> dromList=dromService.find("from Drom", Drom.class, null);
//		   this.put("classList", classList);
//		   this.put("dromList", dromList);
			return "tocreate";
		}
	   public String toupdate() throws Exception{
		  
		
		   Drom drom=dromService.get(Drom.class, model.getId());
			
			super.push(drom);
			return "toupdate";
		   
	   }
	   public String update() throws Exception{
			
		   dromService.saveOrUpdate(model);
			return SUCCESS;
		}
	   public String delete() throws Exception {
			//单条删除
			//deptService.deleteById(Dept.class,model.getId());
			System.out.println(model.getId());
			String[] ids=model.getId().split(", ");
			dromService.delete(Drom.class, ids);
			return SUCCESS;
		}
}
