package cn.xyafu.drom.action.sysadmin;

import java.util.List;

import com.opensymphony.xwork2.ModelDriven;

import cn.xyafu.drom.action.BaseAction;
import cn.xyafu.drom.domain.News;
import cn.xyafu.drom.domain.Student;
import cn.xyafu.drom.service.NewsService;

public class NewsAction extends BaseAction implements ModelDriven<News>{
 private News model=new News();
 private NewsService newsService;
public News getModel() {
	return model;
}
public void setModel(News model) {
	this.model = model;
}
public NewsService getNewsService() {
	return newsService;
}
public void setNewsService(NewsService newsService) {
	this.newsService = newsService;
}

    public String list() throws Exception {
	//通过Service查找数据
	String hql="from News";
	List<News> newsList=newsService.find(hql, News.class, null);
	super.put("newsList",newsList);
	
	return "list";
}
    public String toview() throws Exception {
		News news=newsService.get(News.class, model.getId());
		
			this.push(news);
			return "toview";
		
	}
    public String insert() throws Exception{
    	newsService.saveOrUpdate(model);
			return SUCCESS;
		}
	   
	   public String tocreate() throws Exception{
			return "tocreate";
		}
    public String toupdate() throws Exception {
    	News news=newsService.get(News.class, model.getId());
    	this.push(news);
			return "toupdate";
		
	}
	public String update() throws Exception {
		
		newsService.saveOrUpdate(model);
		return SUCCESS;
		
	}
	 public String delete() throws Exception {
			//单条删除
			//deptService.deleteById(Dept.class,model.getId());
			System.out.println(model.getId());
			String[] ids=model.getId().split(", ");
			newsService.delete(News.class, ids);
			return SUCCESS;
		}
}
