package cn.xyafu.drom.action.student;

import java.util.List;

import com.opensymphony.xwork2.ModelDriven;

import cn.xyafu.drom.action.BaseAction;
import cn.xyafu.drom.domain.Message;
import cn.xyafu.drom.domain.News;
import cn.xyafu.drom.service.MessageService;

public class MessageAction extends BaseAction implements ModelDriven<Message>{
   private Message model=new Message();
   private MessageService messageService;
public Message getModel() {
	return model;
}
public void setModel(Message model) {
	this.model = model;
}
public MessageService getMessageService() {
	return messageService;
}
public void setMessageService(MessageService messageService) {
	this.messageService = messageService;
}


	public String list() throws Exception {
		List<Message> mesList=messageService.find("from Message m where m.student.id='"+model.getId()+"'", Message.class,null);
		if(mesList!=null) {
			this.put("mesList", mesList);
		}else {
			this.put("msg", "你没有留言！！");
		}
		return "list";
	}
	public String toview() throws Exception {
		Message mes=messageService.get(Message.class, model.getId());
		this.push(mes);
		return "toview";
	}
	public String tocreate() throws Exception {
		
		return "tocreate";
	}
	public String insert() throws Exception {
		messageService.saveOrUpdate(model);
		return "toview";
	}
	public String delete() throws Exception {
		//单条删除
		//deptService.deleteById(Dept.class,model.getId());
		System.out.println(model.getId());
		String[] ids=model.getId().split(", ");
		messageService.delete(Message.class, ids);
		return SUCCESS;
	}

}
