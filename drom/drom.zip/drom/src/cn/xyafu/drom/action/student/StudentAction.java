package cn.xyafu.drom.action.student;

import java.util.ArrayList;
import java.util.List;

import com.opensymphony.xwork2.ModelDriven;

import cn.xyafu.drom.action.BaseAction;
import cn.xyafu.drom.domain.Classes;
import cn.xyafu.drom.domain.Drom;
import cn.xyafu.drom.domain.Student;
import cn.xyafu.drom.service.ClassService;
import cn.xyafu.drom.service.DromService;
import cn.xyafu.drom.service.StudentService;
import cn.xyafu.drom.util.Page;

public class StudentAction extends BaseAction implements ModelDriven<Student>{
	private Student model=new Student();
	public Student getModel() {
			return model;
		}
    private ClassService classService;
	
	public void setClassService(ClassService classService) {
		this.classService = classService;
	}
	private DromService dromService;
		
	public void setDromService(DromService dromService) {
		this.dromService = dromService;
	}
		private StudentService studentService;

		public void setStudentService(StudentService studentService) {
			this.studentService = studentService;
		}
		//分页组件
		private Page<Student> page=new Page<Student>();

		public Page<Student> getPage() {
			return page;
		}
		public void setPage(Page<Student> page) {
			this.page = page;
		}
		
		public String list() throws Exception {
			//通过Service查找数据
			String hql="from Student";
			studentService.findPage(hql, page, Student.class, null);
			//设置分页组件的url
			page.setUrl("studentAction_list");//相对定位
			//将page组件手动放入栈顶
			super.push(page);
			
			return "list";
		}
		public String toview() throws Exception{
			Student stu=studentService.get(Student.class, model.getId());
			if(stu!=null) {
			this.push(stu);
			
			}
			return "toview";	
		}
	   public String insert() throws Exception{
		   studentService.saveOrUpdate(model);
			return SUCCESS;
		}
	   
	   public String tocreate() throws Exception{
		   List<Student> stuList=studentService.find("from Student", Student.class, null);
		   super.put("stuList", stuList);
		   List<Classes> claList=classService.find("from Classes", Classes.class, null);
		   List<Drom> dromList=dromService.find("from Drom", Drom.class, null);		   
		   super.put("classList", claList);
		   super.put("dromList", dromList);
		  
			return "tocreate";
		}
	   public String toupdate() throws Exception{
		  
//		   List<Classes> claList=classService.find("from Classes", Classes.class, null);
//		   List<Drom> dromList=dromService.find("from Drom", Drom.class, null);		   
//		   super.put("classList", claList);
//		   super.put("dromList", dromList);
		
		   Student stu=studentService.get(Student.class, model.getId());
			
			super.push(stu);
			return "toupdate";
		   
	   }
	   public String update() throws Exception{
			
		   studentService.saveOrupdate(model);
			return toview();
		}
	   public String delete() throws Exception {
			//单条删除
			//deptService.deleteById(Dept.class,model.getId());
			System.out.println(model.getId());
			String[] ids=model.getId().split(", ");
			studentService.delete(Student.class, ids);
			return SUCCESS;
		}
	

}
