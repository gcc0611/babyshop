package cn.xyafu.drom.action.sysadmin;

import com.opensymphony.xwork2.ModelDriven;

import cn.xyafu.drom.action.BaseAction;
import cn.xyafu.drom.domain.Message;
import cn.xyafu.drom.service.MessageService;

public class MessageAction extends BaseAction implements ModelDriven<Message>{
   private Message model=new Message();
   private MessageService messageService;
public Message getModel() {
	return model;
}
public void setModel(Message model) {
	this.model = model;
}
public MessageService getMessageService() {
	return messageService;
}
public void setMessageService(MessageService messageService) {
	this.messageService = messageService;
}
}
