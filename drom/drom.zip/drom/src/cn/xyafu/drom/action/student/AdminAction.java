package cn.xyafu.drom.action.student;

import java.util.List;

import com.opensymphony.xwork2.ModelDriven;

import cn.xyafu.drom.action.BaseAction;
import cn.xyafu.drom.domain.Admin;
import cn.xyafu.drom.domain.News;
import cn.xyafu.drom.domain.Student;
import cn.xyafu.drom.service.AdminService;
import cn.xyafu.drom.service.NewsService;

public class AdminAction extends BaseAction implements ModelDriven<Admin>{
     private Admin model=new Admin();
     private AdminService adminService;
     private NewsService newsService;
	public NewsService getNewsService() {
		return newsService;
	}

	public void setNewsService(NewsService newsService) {
		this.newsService = newsService;
	}

	public AdminService getAdminService() {
		return adminService;
	}

	public void setAdminService(AdminService adminService) {
		this.adminService = adminService;
	}

	public Admin getModel() {
		return model;
	}

	public void setModel(Admin model) {
		this.model = model;
	}
	public String list() throws Exception {
		//通过Service查找数据
		String hql="from News";
		List<News> newsList=newsService.find(hql,  News.class, null);
		this.put("newsList", newsList);
		
		return "list";
	}
	
	public String toview() throws Exception {
		Admin admin=adminService.get(Admin.class, model.getId());
		
			this.push(admin);
			return "toview";
		
	}
	
	public String toupdate() throws Exception {
		Admin admin=adminService.get(Admin.class, model.getId());
			this.push(admin);
			return "toupdate";
		
	}
	public String update() throws Exception {
		adminService.saveOrUpdate(model);
		return toview();
		
	}
}
