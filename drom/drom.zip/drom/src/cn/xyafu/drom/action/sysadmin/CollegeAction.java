package cn.xyafu.drom.action.sysadmin;



import com.opensymphony.xwork2.ModelDriven;
import cn.xyafu.drom.action.BaseAction;
import cn.xyafu.drom.domain.College;
import cn.xyafu.drom.service.CollegeService;
import cn.xyafu.drom.util.Page;

public class CollegeAction extends BaseAction implements ModelDriven<College>{
  private College model=new College();
  public College getModel() {
		return model;
	}

	private CollegeService collegeService;

	public void setCollegeService(CollegeService collegeService) {
		this.collegeService = collegeService;
	}
	//分页组件
	private Page<College> page=new Page<College>();

	public Page<College> getPage() {
		return page;
	}
	public void setPage(Page<College> page) {
		this.page = page;
	}
	
	public String list() throws Exception {
		//通过Service查找数据
		String hql="from College";
		collegeService.findPage(hql, page, College.class, null);
		//设置分页组件的url
		page.setUrl("collegeAction_list");//相对定位
		//将page组件手动放入栈顶
		super.push(page);
		
		return "list";
	}
	public String toview() throws Exception{
		return "toview";
	}
   public String insert() throws Exception{
	collegeService.saveOrUpdate(model);
		return SUCCESS;
	}
   
   public String tocreate() throws Exception{
		return "tocreate";
	}
   public String toupdate() throws Exception{
	  
	
	   College coll=collegeService.get(College.class, model.getId());
		
		super.push(coll);
		return "toupdate";
	   
   }
   public String update() throws Exception{
		
	   collegeService.saveOrUpdate(model);
		return SUCCESS;
	}
   public String delete() throws Exception {
		//单条删除
		//deptService.deleteById(Dept.class,model.getId());
		System.out.println(model.getId());
		String[] ids=model.getId().split(", ");
		collegeService.delete(College.class, ids);
		return SUCCESS;
	}
}
