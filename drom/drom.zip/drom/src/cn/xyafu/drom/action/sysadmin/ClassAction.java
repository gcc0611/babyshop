package cn.xyafu.drom.action.sysadmin;

import java.util.List;

import com.opensymphony.xwork2.ModelDriven;
import cn.xyafu.drom.domain.Classes;
import cn.xyafu.drom.action.BaseAction;
import cn.xyafu.drom.service.ClassService;
import cn.xyafu.drom.service.DromService;
import cn.xyafu.drom.util.Page;

public class ClassAction extends BaseAction implements ModelDriven<Classes>{
	private Classes model=new Classes();
	private ClassService classService;
	private DromService dromService;
	
	  public DromService getDromService() {
		return dromService;
	}
	public void setDromService(DromService dromService) {
		this.dromService = dromService;
	}
	public ClassService getClassService() {
		return classService;
	}
	public void setClassService(ClassService classService) {
		this.classService = classService;
	}
	public Classes getModel() {
			return model;
		}

		//分页组件
		private Page<Classes> page=new Page<Classes>();

		public Page<Classes> getPage() {
			return page;
		}
		public void setPage(Page<Classes> page) {
			this.page = page;
		}
		
		public String list() throws Exception {
			//通过Service查找数据
			String hql="from Classes";
			classService.findPage(hql, page, Classes.class, null);
			//设置分页组件的url
			page.setUrl("classAction_list");//相对定位
			//将page组件手动放入栈顶
			super.push(page);
			
			return "list";
		}
		public String toview() throws Exception{
			Classes cla=classService.get(Classes.class, model.getId());
			if(cla!=null) {
			this.push(cla);
			return "toview";
			}else {
				super.put("msg","该用户不存在或账号错误");
				return list();
			}
				
		}
	   public String insert() throws Exception{
		   classService.saveOrUpdate(model);
			return SUCCESS;
		}
	   
	   public String tocreate() throws Exception{
		   List<Classes> classList=classService.find("from Classes", Classes.class, null);
//		   List<Drom> dromList=dromService.find("from Drom", Drom.class, null);
		   this.put("classList", classList);
//		   this.put("dromList", dromList);
			return "tocreate";
		}
	   public String toupdate() throws Exception{
		  
		
		   Classes cla=classService.get(Classes.class, model.getId());
			
			super.push(cla);
			return "toupdate";
		   
	   }
	   public String update() throws Exception{
			
		   classService.saveOrUpdate(model);
			return SUCCESS;
		}
	   public String delete() throws Exception {
			//单条删除
			//deptService.deleteById(Dept.class,model.getId());
			System.out.println(model.getId());
			String[] ids=model.getId().split(", ");
			classService.delete(Classes.class, ids);
			return SUCCESS;
		}
	

}
