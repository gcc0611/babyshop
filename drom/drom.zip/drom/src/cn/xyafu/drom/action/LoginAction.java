package cn.xyafu.drom.action;

import java.util.List;

import cn.xyafu.drom.domain.Admin;
import cn.xyafu.drom.domain.News;
import cn.xyafu.drom.domain.Student;
import cn.xyafu.drom.service.AdminService;
import cn.xyafu.drom.service.NewsService;
import cn.xyafu.drom.service.StudentService;

/**
 * 
 * @Description:
 * @author:     传智播客 java学院    传智.袁新奇
 * @version:    1.0
 * @Company:    http://java.itcast.cn 
 * @date:       2016年9月17日
 */
public class LoginAction extends BaseAction {

	private static final long serialVersionUID = 1L;

	private String id;
	private String pwd;
	private Integer sf;
	private AdminService adminService;
	private StudentService studentService;
	private NewsService newsService;
	
	public NewsService getNewsService() {
		return newsService;
	}
	public void setNewsService(NewsService newsService) {
		this.newsService = newsService;
	}
	public StudentService getStudentService() {
		return studentService;
	}
	public void setStudentService(StudentService studentService) {
		this.studentService = studentService;
	}
	public AdminService getAdminService() {
		return adminService;
	}
	public void setAdminService(AdminService adminService) {
		this.adminService = adminService;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public Integer getSf() {
		return sf;
	}
	public void setSf(Integer sf) {
		this.sf = sf;
	}

	public String login() throws Exception {
		if(sf!=null&& !"".equals(sf)) {
			if(sf==1) {
				Admin admin=adminService.get(Admin.class, id);
				if(admin!=null && pwd.equals(admin.getAdmin_pwd())){
					session.put("ad", admin);
					List<News> newsList=newsService.find("from News", News.class, null);
					session.put("newsList", newsList);
					return "admin";
				}else {
					request.put("msg", "账号密码错误，请重新输入！！");
					return "login";
				}
			}else {
				Student stu=studentService.get(Student.class, id);
				if(stu!=null&& pwd.equals(stu.getStu_pwd())) {
					session.put("stu", stu);
					List<News> newsList=newsService.find("from News", News.class, null);
					session.put("newsList", newsList);
					return "student";
				}else {
					request.put("msg", "账号密码错误，请重新输入！！");
					return "login";
				}
			}
		}else {
		request.put("msg", "账号密码错误，请重新输入！！");
		return "login";
		}
		}
  
	public String logout() throws Exception {
		
		session.remove("stu");
		session.remove("ad");
		return "logout";
	}
}

