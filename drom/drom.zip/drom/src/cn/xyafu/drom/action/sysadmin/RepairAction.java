package cn.xyafu.drom.action.sysadmin;

import java.util.List;

import com.opensymphony.xwork2.ModelDriven;

import cn.xyafu.drom.action.BaseAction;
import cn.xyafu.drom.domain.Repair;
import cn.xyafu.drom.service.DromService;
import cn.xyafu.drom.service.RepairService;
import cn.xyafu.drom.service.StudentService;

public class RepairAction extends BaseAction implements ModelDriven<Repair>{
    private Repair model=new Repair();
    private RepairService repairService;

	public Repair getModel() {
		return model;
	}
	public void setModel(Repair model) {
		this.model = model;
	}
	public RepairService getRepairService() {
		return repairService;
	}
	public void setRepairService(RepairService repairService) {
		this.repairService = repairService;
	}
	public String list() throws Exception {
		//通过Service查找数据
		String hql="from Repair";
		List<Repair> repairList=repairService.find(hql, Repair.class, null);
		this.put("repairList", repairList);
		return "list";
	}
	public String toview() throws Exception{
		
		
//		List<Student> repairList=repairService.find("from Repair r where r.student.drom.drom_hao='"+model.getStudent().getDrom().getDrom_hao()+"'",Repair.class, null);
		List<Repair> repList=repairService.find("from Repair r where r.id='"+model.getId()+"'",Repair.class, null);
		if(repList!=null) {
		
		this.put("repList",repList);
		return "toview";
		}else {
			super.put("msg","账号错误,请重新输入");
			return list();
		}
			
	}
   public String insert() throws Exception{
	   repairService.saveOrUpdate(model);
		return toview();
	}
   
   public String tocreate() throws Exception{
//	   List<Class> classList=classService.find("from Class", Class.class, null);
//	   List<Drom> dromList=dromService.find("from Drom", Drom.class, null);
//	   this.put("classList", classList);
//	   this.put("dromList", dromList);
		return "tocreate";
	}
   public String toupdate() throws Exception{
	  
	
	   Repair drom=repairService.get(Repair.class, model.getId());
		
		super.push(drom);
		return "toupdate";
	   
   }
   public String update() throws Exception{
		
	   repairService.saveOrUpdate(model);
		return SUCCESS;
	}
   public String delete() throws Exception {
		//单条删除
		//deptService.deleteById(Dept.class,model.getId());
		System.out.println(model.getId());
		String[] ids=model.getId().split(", ");
		repairService.delete(Repair.class, ids);
		return SUCCESS;
	} 
}
