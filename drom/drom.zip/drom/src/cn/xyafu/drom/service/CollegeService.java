package cn.xyafu.drom.service;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

import cn.xyafu.drom.domain.College;
import cn.xyafu.drom.util.Page;

public interface CollegeService {
	public  List<College> find(String hql, Class<College> entityClass, Object[] params);
	//获取一条记录
	public  College get(Class<College> entityClass, Serializable id);
	//分页查询，将数据封装到一个page分页工具类对象
	public  Page<College> findPage(String hql, Page<College> page, Class<College> entityClass, Object[] params);
	public  void saveOrUpdate(College entity);
    public  void saveOrUpdateAll(Collection<College> entitys);
	
	//单条删除，按id
	public void deleteById(Class<College> entityClass, Serializable id);
	//批量删除
	public void delete(Class<College> entityClass, Serializable[] ids);
}

