package cn.xyafu.drom.service.impl;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import cn.xyafu.drom.dao.BaseDao;
import cn.xyafu.drom.domain.College;
import cn.xyafu.drom.domain.Student;
import cn.xyafu.drom.service.StudentService;
import cn.xyafu.drom.util.Page;

public class StudentServiceImpl implements StudentService{
private BaseDao baseDao;
	
	public void setBaseDao(BaseDao baseDao) {
		this.baseDao=baseDao;
	}

	public Student get(Class<Student> entityClass, Serializable id) {
		
		return baseDao.get(entityClass, id);
	}

	public List<Student> find(String hql, Class<Student> entityClass, Object[] params) {
		
		return baseDao.find(hql, entityClass, params);
	}
	
	public Page<Student> findPage(String hql, Page<Student> page, Class<Student> entityClass, Object[] params) {
		// TODO Auto-generated method stub
		return baseDao.findPage(hql, page, entityClass, params);
	}
	@Override
	public void saveOrUpdate(Student entity) {
		Student stu=baseDao.get(Student.class, entity.getId());
		if(stu==null) {
//			   entity.setId(entity.getId());
//			   entity.setClasses(entity.getClasses());
//			   entity.setDrom(entity.getDrom());
//			  
//			   entity.setStu_name(entity.getStu_name());
//			   entity.setStu_sex(entity.getStu_sex());
//			   entity.setStu_pwd(entity.getStu_pwd());
			   baseDao.saveOrUpdate(entity);
			   }else {
				   
				   stu.setId(entity.getId());
				   stu.setClasses(entity.getClasses());
				   stu.setDrom(entity.getDrom());
				   stu.setStu_name(entity.getStu_name());
				   stu.setStu_sex(entity.getStu_sex());
				   stu.setStu_pwd(entity.getStu_pwd());
				   baseDao.saveOrUpdate(stu);
				   
			   }
	}
	@Override
	public void saveOrUpdateAll(Collection<Student> entitys) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void deleteById(Class<Student> entityClass, Serializable id) {
		Student stu=baseDao.get(Student.class, id);
		if(stu!=null) {
			baseDao.deleteById(Student.class, id);
		}
		
	}
	@Override
	public void delete(Class<Student> entityClass, Serializable[] ids) {
		for(Serializable id:ids) {
			deleteById(entityClass, id);
			
			}
	}

	@Override
	public void saveOrupdate(Student entity) {
	
				   Student stu=baseDao.get(Student.class, entity.getId());
				   stu.setStu_pwd(entity.getStu_pwd());
				   baseDao.saveOrUpdate(stu);
				   
			   }
		
	
	

}
