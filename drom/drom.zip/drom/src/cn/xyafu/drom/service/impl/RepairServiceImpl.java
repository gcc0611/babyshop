package cn.xyafu.drom.service.impl;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import cn.xyafu.drom.common.SysConstant;
import cn.xyafu.drom.dao.BaseDao;
import cn.xyafu.drom.domain.Repair;
import cn.xyafu.drom.domain.Student;
import cn.xyafu.drom.service.RepairService;
import cn.xyafu.drom.util.Page;

public class RepairServiceImpl implements RepairService{
   private BaseDao baseDao;

public BaseDao getBaseDao() {
	return baseDao;
}

public void setBaseDao(BaseDao baseDao) {
	this.baseDao = baseDao;
}

@Override
public List<Repair> find(String hql, Class<Repair> entityClass, Object[] params) {
	// TODO Auto-generated method stub
	return baseDao.find(hql, entityClass, params);
}

@Override
public Repair get(Class<Repair> entityClass, Serializable id) {
	// TODO Auto-generated method stub
	return baseDao.get(entityClass, id);
}



@Override
public void saveOrUpdate(Repair entity) {
	
	Repair repair=baseDao.get(Repair.class,entity.getId());
	if(repair.getState()==0) {
	   repair.setState(SysConstant.ENABLE);
	   baseDao.saveOrUpdate(repair);
	}else {
	repair.setState(SysConstant.DISABLE);
		   baseDao.saveOrUpdate(repair);
	}
	   
   
}

@Override
public void saveOrUpdateAll(Collection<Repair> entitys) {
	// TODO Auto-generated method stub
	
}

@Override
public void deleteById(Class<Repair> entityClass, Serializable id) {
	Repair repair=baseDao.get(Repair.class, id);
	if(repair!=null) {
		
		baseDao.deleteById(entityClass, id);
	}
}

@Override
public void delete(Class<Repair> entityClass, Serializable[] ids) {
	for(Serializable id:ids) {
		deleteById(entityClass, id);
		
		}
	
}

@Override
public Page<Repair> findPage(String hql, Page<Repair> page, Class<Repair> entityClass, Object[] params) {
	// TODO Auto-generated method stub
	return null;
}

@Override
public void saveOrupdate(Repair entity) {
	Student stu=baseDao.get(Student.class, entity.getStudent().getId());
	Repair repair=baseDao.get(Repair.class,entity.getId());
	if(repair==null) {
	   entity.setState(SysConstant.DISABLE);
	   entity.setStudent(stu);
	   entity.setCreate_time(new Date());
	   baseDao.saveOrUpdate(entity);
	}else {
	repair.setState(SysConstant.DISABLE);
		   baseDao.saveOrUpdate(repair);
	
}

}
}
