package cn.xyafu.drom.service.impl;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import cn.xyafu.drom.dao.BaseDao;
import cn.xyafu.drom.domain.College;
import cn.xyafu.drom.service.CollegeService;
import cn.xyafu.drom.util.Page;


public class CollegeServiceImpl implements CollegeService{
    private BaseDao baseDao;
	
	public void setBaseDao(BaseDao baseDao) {
		this.baseDao=baseDao;
	}
	
	public void saveOrUpdate(College entity) {
		if(StringUtils.isBlank(entity.getId())) {
		   entity.setId(entity.getId());
		   entity.setCollege_name(entity.getCollege_name());
			   baseDao.saveOrUpdate(entity);
		   }else {
			   College col=baseDao.get(College.class, entity.getId());
			   col.setId(entity.getId());
			   col.setCollege_name(entity.getCollege_name());
		       baseDao.saveOrUpdate(col);
			   
		   }
		
}

	@Override
	public List<College> find(String hql, Class<College> entityClass, Object[] params) {
		// TODO Auto-generated method stub
		return baseDao.find(hql, entityClass, params);
	}

	@Override
	public College get(Class<College> entityClass, Serializable id) {
		// TODO Auto-generated method stub
		return baseDao.get(entityClass, id);
		
	}

	@Override
	public Page<College> findPage(String hql, Page<College> page, Class<College> entityClass, Object[] params) {
		// TODO Auto-generated method stub
		return baseDao.findPage(hql, page, entityClass, params);
	}

	@Override
	public void saveOrUpdateAll(Collection<College> entitys) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteById(Class<College> entityClass, Serializable id) {

		College col=baseDao.get(College.class, id);
		if(col!=null) {
			baseDao.deleteById(College.class, id);
		}
		
	}

	@Override
	public void delete(Class<College> entityClass, Serializable[] ids) {
		for(Serializable id:ids) {
			deleteById(entityClass, id);
			
			}
		
	}
	
}
