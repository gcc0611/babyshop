package cn.xyafu.drom.service.impl;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import cn.xyafu.drom.dao.BaseDao;
import cn.xyafu.drom.domain.Classes;
import cn.xyafu.drom.domain.Student;
import cn.xyafu.drom.service.ClassService;
import cn.xyafu.drom.util.Page;

public class ClassServiceImpl implements ClassService{
    private BaseDao baseDao;
	public void setBaseDao(BaseDao baseDao) {
		this.baseDao = baseDao;
	}

	@Override
	public List<Classes> find(String hql, Class<Classes> entityClass, Object[] params) {
		// TODO Auto-generated method stub
		return baseDao.find(hql,entityClass, params);
	}

	@Override
	public Classes get(Class<Classes> entityClass, Serializable id) {
		// TODO Auto-generated method stub
		return baseDao.get(entityClass, id);
	}

	@Override
	public Page<Classes> findPage(String hql, Page<Classes> page, Class<Classes> entityClass, Object[] params) {
		// TODO Auto-generated method stub
		return baseDao.findPage(hql, page, entityClass, params);
	}

	@Override
	public void saveOrUpdate(Classes entity) {
		if(StringUtils.isBlank(entity.getId())) {
			   baseDao.saveOrUpdate(entity);
			   }else {
				   entity.setId(entity.getId());
				   entity.setClass_name(entity.getClass_name());
				   entity.setProFession(entity.getProFession());
				   entity.setStudents(entity.getStudents());
				   baseDao.saveOrUpdate(entity);
				   
			   }
	}

	@Override
	public void saveOrUpdateAll(Collection<Classes> entitys) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteById(Class<Classes> entityClass, Serializable id) {
		Classes cla=baseDao.get(Classes.class, id);
		if(cla!=null) {
			baseDao.deleteById(Classes.class, id);
		}
	}

	@Override
	public void delete(Class<Classes> entityClass, Serializable[] ids) {
		for(Serializable id:ids) {
			deleteById(entityClass, id);
			
			}
	}


}
