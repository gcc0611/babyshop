package cn.xyafu.drom.service.impl;

import java.io.Serializable;

import org.apache.commons.lang.StringUtils;

import cn.xyafu.drom.dao.BaseDao;
import cn.xyafu.drom.domain.Admin;
import cn.xyafu.drom.service.AdminService;

public class AdminServiceImpl implements AdminService{
   private BaseDao baseDao;
	public BaseDao getBaseDao() {
	return baseDao;
}
public void setBaseDao(BaseDao baseDao) {
	this.baseDao = baseDao;
}
	@Override
	public Admin get(Class<Admin> entityClass, Serializable id) {
		// TODO Auto-generated method stub
		return baseDao.get(entityClass, id);
	}
	@Override
	public void saveOrUpdate(Admin entity) {
		if(StringUtils.isBlank(entity.getId())) {
			baseDao.saveOrUpdate(entity);
		}else {
			Admin admin=baseDao.get(Admin.class, entity.getId());
			admin.setId(entity.getId());
			admin.setAdmin_name(entity.getAdmin_name());
			admin.setAdmin_pwd(entity.getAdmin_pwd());
			baseDao.saveOrUpdate(admin);
		}
		
	}

}
