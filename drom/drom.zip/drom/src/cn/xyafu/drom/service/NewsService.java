package cn.xyafu.drom.service;

import java.io.Serializable;
import java.util.List;

import cn.xyafu.drom.domain.News;

public interface NewsService {
	        //查询所有，带条件查询
			public  List<News> find(String hql, Class<News> entityClass, Object[] params);
			//获取一条记录
			public News get(Class<News> entityClass, Serializable id);
			//新增和修改保存
			public void saveOrUpdate(News entity);
			//单条删除，按id
			public void deleteById(Class<News> entityClass, Serializable id);
			//批量删除
			public void delete(Class<News> entityClass, Serializable[] ids);
}
