package cn.xyafu.drom.service.impl;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

import cn.xyafu.drom.common.SysConstant;
import cn.xyafu.drom.dao.BaseDao;
import cn.xyafu.drom.domain.Drom;
import cn.xyafu.drom.service.DromService;
import cn.xyafu.drom.util.Page;

public class DromServiceImpl implements DromService{
 private BaseDao baseDao;

public void setBaseDao(BaseDao baseDao) {
	this.baseDao = baseDao;
}

	@Override
	public List<Drom> find(String hql, Class<Drom> entityClass, Object[] params) {
		// TODO Auto-generated method stub
		return baseDao.find(hql, entityClass, params);
	}

	@Override
	public Drom get(Class<Drom> entityClass, Serializable id) {
		// TODO Auto-generated method stub
		return baseDao.get(entityClass, id);
	}

	@Override
	public Page<Drom> findPage(String hql, Page<Drom> page, Class<Drom> entityClass, Object[] params) {
		// TODO Auto-generated method stub
		return baseDao.findPage(hql, page, entityClass, params);
	}

	@Override
	public void saveOrUpdate(Drom entity) {
		
		Drom drom=baseDao.get(Drom.class,entity.getId());
		if(drom!=null) {
		int a_money=Integer.parseInt(drom.getBillinfo().getMoney());
		int b_money=Integer.parseInt(entity.getBillinfo().getMoney());
		System.out.println(a_money);
		System.out.println(b_money);
		int c=a_money+b_money;
		
		
		if(drom.getBillinfo().getMoney()!=null) {
			drom.getBillinfo().setMoney(String.valueOf(c));;
			baseDao.saveOrUpdate(drom);
		}
		}else {
			baseDao.saveOrUpdate(entity);
		}
	}

	@Override
	public void saveOrUpdateAll(Collection<Drom> entitys) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteById(Class<Drom> entityClass, Serializable id) {
		Drom drom=baseDao.get(Drom.class, id);
		if(drom!=null) {
			
			baseDao.deleteById(entityClass, id);
		}
	}

	@Override
	public void delete(Class<Drom> entityClass, Serializable[] ids) {
		for(Serializable id:ids) {
			deleteById(entityClass, id);
			
			}
		
	}

}
