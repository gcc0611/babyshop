package cn.xyafu.drom.service;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

import cn.xyafu.drom.domain.Repair;
import cn.xyafu.drom.util.Page;

public interface RepairService {
	//查询所有，带条件查询
		public List<Repair> find(String hql, Class<Repair> entityClass, Object[] params);
		//获取一条记录
		public Repair get(Class<Repair> entityClass, Serializable id);
		//分页查询，将数据封装到一个page分页工具类对象
		public Page<Repair> findPage(String hql, Page<Repair> page, Class<Repair> entityClass, Object[] params);
		
		//新增和修改保存
		public  void saveOrUpdate(Repair entity);
		//批量新增和修改保存
		public  void saveOrUpdateAll(Collection<Repair> entitys);
		
		//单条删除，按id
		public void deleteById(Class<Repair> entityClass, Serializable id);
		//批量删除
		public void delete(Class<Repair> entityClass, Serializable[] ids);
		public void saveOrupdate(Repair entity);
}
