package cn.xyafu.drom.service.impl;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.apache.commons.lang.StringUtils;

import cn.xyafu.drom.dao.BaseDao;
import cn.xyafu.drom.domain.Message;
import cn.xyafu.drom.domain.News;
import cn.xyafu.drom.service.MessageService;
import cn.xyafu.drom.util.Page;

public class MessageServiceImpl implements MessageService{
      private BaseDao baseDao;
      
	public BaseDao getBaseDao() {
		return baseDao;
	}

	public void setBaseDao(BaseDao baseDao) {
		this.baseDao = baseDao;
	}

	@Override
	public List<Message> find(String hql, Class<Message> entityClass, Object[] params) {
		// TODO Auto-generated method stub
		return baseDao.find(hql, entityClass, params);
	}

	@Override
	public Message get(Class<Message> entityClass, Serializable id) {
		// TODO Auto-generated method stub
		return baseDao.get(entityClass, id);
	}

	@Override
	public Page<Message> findPage(String hql, Page<Message> page, Class<Message> entityClass, Object[] params) {
		// TODO Auto-generated method stub
		return baseDao.findPage(hql, page, entityClass, params);
	}

	@Override
	public void saveOrUpdate(Message entity) {
		if(entity.getContent()!=null){
				String id=UUID.randomUUID().toString();
             entity.setId(id);
             entity.setM_title(entity.getContent().length()>=10?entity.getContent().substring(0, 4)+"....":entity.getContent());
//             entity.setStudent().setId(entity.getId());
             baseDao.saveOrUpdate(entity);
			
		}
	
		
	}

	@Override
	public void saveOrUpdateAll(Collection<Message> entitys) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteById(Class<Message> entityClass, Serializable id) {
		Message  mes=baseDao.get(Message.class, id);
		if(mes!=null) {
			baseDao.deleteById(entityClass, id);
		}
		
	}

	@Override
	public void delete(Class<Message> entityClass, Serializable[] ids) {
		for(Serializable id:ids) {
			deleteById(entityClass, id);
			
			}
		
	}

}
