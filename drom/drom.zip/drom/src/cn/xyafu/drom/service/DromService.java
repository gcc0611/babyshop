package cn.xyafu.drom.service;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

import cn.xyafu.drom.domain.Drom;
import cn.xyafu.drom.util.Page;

public interface DromService {
	//查询所有，带条件查询
		public  List<Drom> find(String hql, Class<Drom> entityClass, Object[] params);
		//获取一条记录
		public Drom get(Class<Drom> entityClass, Serializable id);
		//分页查询，将数据封装到一个page分页工具类对象
		public Page<Drom> findPage(String hql, Page<Drom> page, Class<Drom> entityClass, Object[] params);
		
		//新增和修改保存
		public void saveOrUpdate(Drom entity);
		//批量新增和修改保存
		public void saveOrUpdateAll(Collection<Drom> entitys);
		
		//单条删除，按id
		public void deleteById(Class<Drom> entityClass, Serializable id);
		//批量删除
		public void delete(Class<Drom> entityClass, Serializable[] ids);
}
