package cn.xyafu.drom.service;

import java.io.Serializable;

import cn.xyafu.drom.domain.Admin;

public interface AdminService {
	public Admin get(Class<Admin> entityClass, Serializable id);

	public void saveOrUpdate(Admin entity);
}
