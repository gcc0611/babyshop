package cn.xyafu.drom.service.impl;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import cn.xyafu.drom.dao.BaseDao;
import cn.xyafu.drom.domain.News;
import cn.xyafu.drom.domain.Student;
import cn.xyafu.drom.service.NewsService;

public class NewsServiceImpl implements NewsService{
   private BaseDao baseDao;
   
	public BaseDao getBaseDao() {
	return baseDao;
}

public void setBaseDao(BaseDao baseDao) {
	this.baseDao = baseDao;
}

	@Override
	public List<News> find(String hql, Class<News> entityClass, Object[] params) {
		// TODO Auto-generated method stub
		return baseDao.find(hql, entityClass, params);
	}

	@Override
	public News get(Class<News> entityClass, Serializable id) {
		// TODO Auto-generated method stub
		return baseDao.get(entityClass, id);
	}

	@Override
	public void saveOrUpdate(News entity) {
		News news=baseDao.get(News.class, entity.getId());
		
		if(news==null) {
			entity.setId(entity.getId());
			entity.setCreate_time(new Date());
			entity.setNews_title(entity.getNews_title());
			baseDao.saveOrUpdate(entity);
		}else {
			
			news.setId(entity.getId());
			news.setCreate_time(new Date());
			news.setNews_title(entity.getNews_title());
			baseDao.saveOrUpdate(news);
		}
		
	}

	@Override
	public void deleteById(Class<News> entityClass, Serializable id) {
		News news=baseDao.get(News.class, id);
		if(news!=null) {
			baseDao.deleteById(entityClass, id);
		}
	}

	@Override
	public void delete(Class<News> entityClass, Serializable[] ids) {
		for(Serializable id:ids) {
			deleteById(entityClass, id);
			
			}
	}

}
