package cn.xyafu.drom.service;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;
import cn.xyafu.drom.domain.Student;
import cn.xyafu.drom.util.Page;

public interface StudentService {
	public  List<Student> find(String hql, Class<Student> entityClass, Object[] params);
	public Student get(Class<Student> entityClass, Serializable id);
	public  Page<Student> findPage(String hql, Page<Student> page, Class<Student> entityClass, Object[] params);
	public  void saveOrUpdate(Student entity);
    public  void saveOrUpdateAll(Collection<Student> entitys);
	
	//单条删除，按id
	public void deleteById(Class<Student> entityClass, Serializable id);
	//批量删除
	public void delete(Class<Student> entityClass, Serializable[] ids);
	public void saveOrupdate(Student entity);

}
