package cn.xyafu.form;


public class Product {
private int pid;
private String pname;
private int price;
private int scprice;
private String[] pictures;
private String pcontent;
private int tid;
private String tname;
private boolean hot;
public boolean isHot() {
	return hot;
}
public void setHot(boolean hot) {
	this.hot = hot;
}
public int getPid() {
	return pid;
}
public void setPid(int pid) {
	this.pid = pid;
}
public String getPname() {
	return pname;
}
public void setPname(String pname) {
	this.pname = pname;
}
public int getPrice() {
	return price;
}
public void setPrice(int price) {
	this.price = price;
}
public int getScprice() {
	return scprice;
}
public void setScprice(int scprice) {
	this.scprice = scprice;
}
public String[] getPictures() {
	return pictures;
}
public void setPictures(String[] pictures) {
	this.pictures = pictures;
}
public String getPcontent() {
	return pcontent;
}
public void setPcontent(String pcontent) {
	this.pcontent = pcontent;
}
public int getTid() {
	return tid;
}
public void setTid(int tid) {
	this.tid = tid;
}
public String getTname() {
	return tname;
}
public void setTname(String tname) {
	this.tname = tname;
}

}
