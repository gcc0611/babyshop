package cn.xyafu.form;

import java.sql.Date;

public class Babynews {
private  int nid ;
private  String nititle;
private  String nijianjie;
private String pic;
private Date ndate;
private String ncontent;
private int times;
public String getPic() {
	return pic;
}
public void setPic(String pic) {
	this.pic = pic;
}
public int getNid() {
	return nid;
}
public void setNid(int nid) {
	this.nid = nid;
}
public String getNititle() {
	return nititle;
}
public void setNititle(String nititle) {
	this.nititle = nititle;
}
public String getNijianjie() {
	return nijianjie;
}
public void setNijianjie(String nijianjie) {
	this.nijianjie = nijianjie;
}
public Date getNdate() {
	return ndate;
}
public void setNdate(Date ndate) {
	this.ndate = ndate;
}
public String getNcontent() {
	return ncontent;
}
public void setNcontent(String ncontent) {
	this.ncontent = ncontent;
}
public int getTimes() {
	return times;
}
public void setTimes(int times) {
	this.times = times;
}

}
