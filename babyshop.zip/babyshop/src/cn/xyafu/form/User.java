package cn.xyafu.form;

public class User {
private String uname;
private String realname;
private String upwd;
private String utel;
private String email;
private String birth;
private int sf;
public String getUname() {
	return uname;
}
public void setUname(String uname) {
	this.uname = uname;
}
public String getRealname() {
	return realname;
}
public void setRealname(String realname) {
	this.realname = realname;
}
public String getUpwd() {
	return upwd;
}
public void setUpwd(String upwd) {
	this.upwd = upwd;
}
public String getUtel() {
	return utel;
}
public void setUtel(String utel) {
	this.utel = utel;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getBirth() {
	return birth;
}
public void setBirth(String birth) {
	this.birth = birth;
}
public int getSf() {
	return sf;
}
public void setSf(int sf) {
	this.sf = sf;
}

}
