package cn.xyafu.form;

import java.util.List;

public class Types {
private int cid;
private String cname;
private List<Ttypes>  tt;
public int getCid() {
	return cid;
}
public void setCid(int cid) {
	this.cid = cid;
}
public String getCname() {
	return cname;
}
public void setCname(String cname) {
	this.cname = cname;
}
public List<Ttypes> getTt() {
	return tt;
}
public void setTt(List<Ttypes> tt) {
	this.tt = tt;
}
}
