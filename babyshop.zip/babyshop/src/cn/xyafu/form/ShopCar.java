package cn.xyafu.form;

public class ShopCar {
private int pid;
private int sum;
private Product pt;
public int getPid() {
	return pid;
}
public void setPid(int pid) {
	this.pid = pid;
}
public int getSum() {
	return sum;
}
public void setSum(int sum) {
	this.sum = sum;
}
public Product getPt() {
	return pt;
}
public void setPt(Product pt) {
	this.pt = pt;
}
}
