package cn.xyafu.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import cn.xyafu.form.Product;
import cn.xyafu.utils.DbUtils;

public class ProductDao {
   DbUtils db=new DbUtils();
	public List<Product> findTodaybuy() throws SQLException {
		String sql="select * from product,ttype where product.tid=ttype.tid order by price limit 8";
		ResultSet rs=db.executeQuery(sql);
		Product pt;
		List<Product> listp=new ArrayList<Product>();
		while(rs.next()){
			pt=new Product();
			pt.setPid(rs.getInt(1));
			pt.setPname(rs.getString(2).length()>=10?rs.getString(2).substring(0,8)+"...":rs.getString(2));
			pt.setPrice(rs.getInt(3)/100);
			pt.setScprice(rs.getInt(4)/100);
			String[] pictures=rs.getString(5).split(";");
			pt.setPictures(pictures);
			pt.setPcontent(rs.getString(6));
			pt.setTid(rs.getInt(7));
			pt.setTname(rs.getString(10));
			pt.setHot(rs.getBoolean(8));
			listp.add(pt);
			
		}
		rs.close();
		db.close();
		return listp;
	}
	
	public List<Product> findRandom() throws SQLException {
		String sql="select * from product,ttype where product.tid=ttype.tid order by rand() limit 15";
		ResultSet rs=db.executeQuery(sql);
		Product pt;
		List<Product> listp=new ArrayList<Product>();
		while(rs.next()){
			pt=new Product();
			pt.setPid(rs.getInt(1));
			pt.setPname(rs.getString(2).length()>=10?rs.getString(2).substring(0,8)+"...":rs.getString(2));
			pt.setPrice(rs.getInt(3)/100);
			pt.setScprice(rs.getInt(4)/100);
			String[] pictures=rs.getString(5).split(";");
			pt.setPictures(pictures);
			pt.setPcontent(rs.getString(6));
			pt.setTid(rs.getInt(7));
			pt.setTname(rs.getString(10));
			pt.setHot(rs.getBoolean(8));
			listp.add(pt);
			
		}
		rs.close();
		db.close();
		return listp;
	}

	public List<Product> findFenpage(int beginp, int psize) throws SQLException {
		String sql="select * from product,ttype where product.tid=ttype.tid order by rand() limit "+beginp+","+psize;
		ResultSet rs=db.executeQuery(sql);
		Product pt;
		List<Product> listp=new ArrayList<Product>();
		while(rs.next()){
			pt=new Product();
			pt.setPid(rs.getInt(1));
			pt.setPname(rs.getString(2).length()>=10?rs.getString(2).substring(0,8)+"...":rs.getString(2));
			pt.setPrice(rs.getInt(3)/100);
			pt.setScprice(rs.getInt(4)/100);
			String[] pictures=rs.getString(5).split(";");
			pt.setPictures(pictures);
			pt.setPcontent(rs.getString(6));
			pt.setTid(rs.getInt(7));
			pt.setTname(rs.getString(10));
			pt.setHot(rs.getBoolean(8));
			listp.add(pt);
	}
		rs.close();
		db.close();
		return listp;
	}

	public int allProducttotal() {
		String sql="select count(*) from product";
		ResultSet rs=db.executeQuery(sql);
		try {
			if(rs.next()){
				return rs.getInt(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
	}

	public Product findById(String id) throws SQLException {
		String sql="select * from product,ttype where product.tid=ttype.tid and pid="+id;
		ResultSet rs=db.executeQuery(sql);
		Product pt=new Product();
		if(rs.next()){
			pt.setPid(rs.getInt(1));
			pt.setPname(rs.getString(2).length()>=10?rs.getString(2).substring(0,8)+"...":rs.getString(2));
			pt.setPrice(rs.getInt(3)/100);
			pt.setScprice(rs.getInt(4)/100);
			String[] pictures=rs.getString(5).split(";");
			pt.setPictures(pictures);
			pt.setPcontent(rs.getString(6));
			pt.setTid(rs.getInt(7));
			pt.setTname(rs.getString(10));
			pt.setHot(rs.getBoolean(8));
		}
		rs.close();
		db.close();
		return pt;
	}

	public List<Product> findTgou() throws SQLException {
		String sql="select * from product,ttype where product.tid=ttype.tid order by price limit 3";
		ResultSet rs=db.executeQuery(sql);
		Product pt;
		List<Product> listp=new ArrayList<Product>();
		while(rs.next()){
			pt=new Product();
			pt.setPid(rs.getInt(1));
			pt.setPname(rs.getString(2).length()>=10?rs.getString(2).substring(0,8)+"...":rs.getString(2));
			pt.setPrice(rs.getInt(3)/100);
			pt.setScprice(rs.getInt(4)/100);
			String[] pictures=rs.getString(5).split(";");
			pt.setPictures(pictures);
			pt.setPcontent(rs.getString(6));
			pt.setTid(rs.getInt(7));
			pt.setTname(rs.getString(10));
			pt.setHot(rs.getBoolean(8));
			listp.add(pt);
			
		}
		rs.close();
		db.close();
		return listp;
	}

	public List<Product> findTm() throws SQLException {
		String sql="select * from product,ttype where product.tid=ttype.tid order by rand() limit 16";
		ResultSet rs=db.executeQuery(sql);
		Product pt;
		List<Product> listp=new ArrayList<Product>();
		while(rs.next()){
			pt=new Product();
			pt.setPid(rs.getInt(1));
			pt.setPname(rs.getString(2).length()>=10?rs.getString(2).substring(0,8)+"...":rs.getString(2));
			pt.setPrice(rs.getInt(3)/100);
			pt.setScprice(rs.getInt(4)/100);
			String[] pictures=rs.getString(5).split(";");
			pt.setPictures(pictures);
			pt.setPcontent(rs.getString(6));
			pt.setTid(rs.getInt(7));
			pt.setTname(rs.getString(10));
			pt.setHot(rs.getBoolean(8));
			listp.add(pt);
			
		}
		rs.close();
		db.close();
		return listp;
	}

	public List<Product> findRexiao() throws SQLException {
		String sql="select * from product,ttype where product.tid=ttype.tid  and hot=1 order by rand() limit 6";
		ResultSet rs=db.executeQuery(sql);
		Product pt;
		List<Product> listp=new ArrayList<Product>();
		while(rs.next()){
			pt=new Product();
			pt.setPid(rs.getInt(1));
			pt.setPname(rs.getString(2).length()>=10?rs.getString(2).substring(0,8)+"...":rs.getString(2));
			pt.setPrice(rs.getInt(3)/100);
			pt.setScprice(rs.getInt(4)/100);
			String[] pictures=rs.getString(5).split(";");
			pt.setPictures(pictures);
			pt.setPcontent(rs.getString(6));
			pt.setTid(rs.getInt(7));
			pt.setTname(rs.getString(10));
			pt.setHot(rs.getBoolean(8));
			listp.add(pt);
			
		}
		rs.close();
		db.close();
		return listp;
	}

}
