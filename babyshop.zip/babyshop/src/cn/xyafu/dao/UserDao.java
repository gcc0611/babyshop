package cn.xyafu.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import cn.xyafu.form.User;
import cn.xyafu.utils.DbUtils;

public class UserDao {
    DbUtils db=new DbUtils();
	public User findByname(String loginname) {
		User user;
		String sql="select *from user where uname='"+loginname+"'";
		ResultSet rs=db.executeQuery(sql);
		try {
			if(rs.next()){
				user=new User();
				user.setUname(rs.getString(1));
				user.setRealname(rs.getString(2));
				user.setUpwd(rs.getString(3));
				user.setUtel(rs.getString(4));
				user.setEmail(rs.getString(5));
				user.setBirth(rs.getString(6));
				user.setSf(rs.getInt(7));
				rs.close();
				db.close();
				return user;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	public int addUser(User user) {
		int flag=0;
		String sql="insert into user values('"+user.getUname()+"','"+
		           user.getRealname()+"','"+user.getUpwd()+"','"+
				   user.getUtel()+"','"+user.getEmail()+"','"+user.getBirth()+"',null)";
		flag=db.executeUpdate(sql);
		db.close();
		return flag;
	}

}
