package cn.xyafu.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import cn.xyafu.form.Product;
import cn.xyafu.form.Ttypes;
import cn.xyafu.form.Types;
import cn.xyafu.utils.DbUtils;

public class TypeDao {
    DbUtils db=new DbUtils();
	public List<Types> findAllType() throws SQLException {
		List<Types> listd=new ArrayList<Types>();
		Types type=null;
		List<Ttypes> listx=null;
		String sql="select * from ctype";
		ResultSet rs=db.executeQuery(sql);
		ResultSet rs2=null;
		while(rs.next()){
			type=new Types();
			type.setCid(rs.getInt(1));
			type.setCname(rs.getString(2));
			listx=new ArrayList<Ttypes>();
			String sql2="select * from ttype where cid="+type.getCid();
		    rs2=db.executeQuery(sql2);
			Ttypes xtype;
			while(rs2.next()){
				xtype=new Ttypes();
				xtype.setTid(rs2.getInt(1));
				xtype.setTname(rs2.getString(2));
				xtype.setCid(rs2.getInt(3));
				listx.add(xtype);
			}
			type.setTt(listx);
			listd.add(type);
		}
		rs2.close();
		rs.close();
		db.close();
		return listd;
	}
	public List<Product> findTid(String id) throws SQLException {
		
		String sql="select * from product where tid="+id;
		ResultSet rs=db.executeQuery(sql);
		Product pt;
		List<Product> listxt=new ArrayList<Product>();
		while(rs.next()){
			pt=new Product();
			pt.setPid(rs.getInt(1));
			pt.setPname(rs.getString(2).length()>=10?rs.getString(2).substring(0,8)+"...":rs.getString(2));
			pt.setPrice(rs.getInt(3)/100);
			pt.setScprice(rs.getInt(4)/100);
			String[] pictures=rs.getString(5).split(";");
			pt.setPictures(pictures);
			pt.setPcontent(rs.getString(6));
			pt.setTid(rs.getInt(7));
			pt.setHot(rs.getBoolean(8));
			listxt.add(pt);
		}
		rs.close();
		db.close();
		return listxt;
	}

}
