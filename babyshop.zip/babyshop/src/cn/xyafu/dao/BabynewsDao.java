package cn.xyafu.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import cn.xyafu.form.Babynews;
import cn.xyafu.utils.DbUtils;

public class BabynewsDao {
	DbUtils db=new DbUtils();
	public List<Babynews> findBynews() throws SQLException {
		String sql="select * from babynews";
		ResultSet rs=db.executeQuery(sql);
		Babynews bs;
		List<Babynews> listbs =new ArrayList<Babynews>();
		while(rs.next()){
			bs=new Babynews();
			bs.setNid(rs.getInt(1));
			bs.setNititle(rs.getString(2));
			bs.setNijianjie(rs.getString(3));
			bs.setPic(rs.getString(4));
			bs.setNdate(rs.getDate(5));
			bs.setNcontent(rs.getString(6));
			bs.setTimes(rs.getInt(7));
			listbs.add(bs);
		}
		rs.close();
		db.close();
		return listbs;
	}

}
