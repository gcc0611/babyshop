package cn.xyafu.servlet;


import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.xyafu.form.Babynews;
import cn.xyafu.form.Product;
import cn.xyafu.form.Types;
import cn.xyafu.service.BabynewsService;
import cn.xyafu.service.ProductService;
import cn.xyafu.service.TypeService;

public class AllSPServlet extends HttpServlet {
@Override
protected void service(HttpServletRequest request, HttpServletResponse response)
		throws ServletException, IOException {
	ProductService ps=new ProductService();
	BabynewsService bs=new BabynewsService();	
	String action =request.getParameter("action");
	
	if(action!=null){
		 if(action.equals("all")){
	  TypeService ts=new TypeService();
	  List<Types> listt=ts.findAllType();
	  
	  
	  int beginp,psize,currp,totalp,count;
	  count=ps.allProducttotal();
	  String currpStr=request.getParameter("currp");
	  if(currpStr==null){
		  currp=1;
	  }else{
		  currp=Integer.parseInt(currpStr);
	  }
	 
	  psize=9;
	  totalp=count%psize==0?count/psize:count/psize+1;
	  if(currp<1){
		  currp=1;
	  }
	  if(currp>totalp){
		  currp=totalp;
	  }
	  beginp=(currp-1)*psize;
	 
	  
	  List<Product> listp=ps.findFenpage(beginp,psize);
	  String id=request.getParameter("id");
	  List<Product> listxt=ts.findTid(id);
	  request.setAttribute("totalp", totalp);
	  request.setAttribute("currp", currp); 
	  request.setAttribute("listt", listt);
	  request.setAttribute("listp", listp);
	  request.setAttribute("listxt",listxt);
	  request.getRequestDispatcher("jsp/commodity.jsp").forward(request, response);
      }
		else if(action.equals("details")){
			//����һ����������Ʒ��id��
			String id=request.getParameter("id");
			//����idֵ��ѯ��Ʒ������ȡ��Ϣ
			Product pr=ps.findById(id);
			//������Ʒ
			List<Product> listr=ps.findRexiao();
			request.setAttribute("listr", listr);
			request.setAttribute("pr", pr);
			request.getRequestDispatcher("jsp/details.jsp").forward(request, response);
		}
		else if(action.equals("information")){
			List<Babynews> listbn=bs.findBynews();
			request.setAttribute("listbn",listbn);
			request.getRequestDispatcher("jsp/information.jsp").forward(request, response);
		}
		else if(action.equals("buytoday")){
			List<Product> listtd=ps.findTodaybuy();
			List<Product> listtm=ps.findTm();
			List<Product> listtg=ps.findTgou();
			request.setAttribute("listtg",listtg);
			request.setAttribute("listtm",listtm);
			request.setAttribute("listtd",listtd);
			request.getRequestDispatcher("jsp/buytoday.jsp").forward(request, response);
		}
     }
   }
}
