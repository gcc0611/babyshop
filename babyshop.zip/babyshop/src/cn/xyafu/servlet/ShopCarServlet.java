package cn.xyafu.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.jms.Session;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.xyafu.form.Product;
import cn.xyafu.form.ShopCar;
import cn.xyafu.form.User;
import cn.xyafu.service.ShopCarService;

public class ShopCarServlet extends HttpServlet {
//������Ϣ�����ﳵ
//ɾ�����ﳵ��Ϣ
//��ʾ���ﳵ��Ϣ
@Override
protected void service(HttpServletRequest request, HttpServletResponse response)
		throws ServletException, IOException {
	User user=(User) request.getSession().getAttribute("user");
	String action=request.getParameter("action");
	if(user==null){
		request.setAttribute("msg", "�ף��㻹û�е�¼�����ȵ�¼��");
		request.getRequestDispatcher("/jsp/info.jsp").forward(request, response);
	}else{
	//���ﳵ
	List<ShopCar> listsc=(List<ShopCar>)request.getSession().getAttribute("listsc");
	List<ShopCar> lisplg=(List<ShopCar>) request.getSession().getAttribute("lisplg");
	ShopCarService scs=new ShopCarService();
	if(action==null){
		
		response.sendRedirect("jsp/shopcar.jsp");
	}else if(action.equals("add")){
		//������Ϣ�����ﳵ
		String id=request.getParameter("id");
		String sum=request.getParameter("sum");
		String submit=request.getParameter("submit");
		if(submit.equals("���빺�ﳵ")){
		listsc=scs.addProduct(listsc,id,sum);
		int n=listsc.size();
		request.getSession().setAttribute("n", n);
		request.getSession().setAttribute("listsc", listsc);
		response.sendRedirect("AllSPServlet?action=details&id="+id);
		}
		else if(submit.equals("��������")){
			 lisplg=scs.findDan(lisplg,id,sum);
			request.setAttribute("msg", "�ף����ʵ����");
			request.getSession().setAttribute("lisplg", lisplg);
			request.getRequestDispatcher("/jsp/info.jsp").forward(request, response);
			
		}
	}else if(action.equals("delete")){
		//ɾ�����ﳵ��Ʒ
		String id=request.getParameter("id");
		listsc=scs.deleteProduct(listsc,id);
		int n=listsc.size();
		request.getSession().setAttribute("n", n);
		request.getSession().setAttribute("listsc", listsc);
		response.sendRedirect("jsp/shopcar.jsp");
	}
	}
}
}
