package cn.xyafu.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.xyafu.form.Product;
import cn.xyafu.form.Types;
import cn.xyafu.service.ProductService;
import cn.xyafu.service.TypeService;

public class SPServlet extends HttpServlet {
  protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
       //1.��Ʒ������Ϣ�б�
	  TypeService ts=new TypeService();
	  List<Types> listt=ts.findAllType();
		//2.���ձ�����Ʒ�б�����Ʒ�۸���͵�8����
	  ProductService ps=new ProductService();
	  List<Product> listp=ps.findTodaybuy();
	  
	  //3.�����Ƽ���Ʒ�б��������ʾ15����Ʒ��
	  List<Product> lists=ps.findRandom();

	  request.setAttribute("listt", listt);
	  request.setAttribute("listp", listp);
	  request.setAttribute("lists", lists);
	  request.getRequestDispatcher("jsp/index.jsp").forward(request, response);
	  
	}
}
