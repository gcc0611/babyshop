package cn.xyafu.utils;

import java.io.InputStream;
import java.sql.*;
import java.util.Properties;


public class Demo {
public static void main(String[] args) throws Exception{
	    DbUtils db=new DbUtils();
		String sql="select * from user";
		ResultSet rs=db.executeQuery(sql);
		while(rs.next()){
			System.out.println(rs.getString(1)+"---"+rs.getString(2)+"---"+rs.getString(3));
		}
		rs.close();
		db.close();
}
}
