package cn.xyafu.utils;

import java.io.IOException;
import java.io.InputStream;
import java.sql.*;
import java.util.Properties;

public class DbUtils {
	public  static 	Properties props=new Properties();
	private Connection conn=null;
	private Statement stmt=null;
	private ResultSet rs=null;
	static {
		InputStream ips=null;
	    ips=Demo.class.getClassLoader().getResourceAsStream("db.properties");
	    try {
			props.load(ips);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	private Connection getConnection(){
		String dbDrivername=props.getProperty("dbDrivername");
		String dbUrl=props.getProperty("dbUrl");
		String dbname=props.getProperty("dbname");
		String dbpwd=props.getProperty("dbpwd");
		try {
			Class.forName(dbDrivername);
			conn=DriverManager.getConnection(dbUrl,dbname,dbpwd);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("���������쳣��");
		}
		  catch (SQLException e) {
			// TODO Auto-generated catch block
			  System.out.println("���ݿ������쳣��");
		}
		return conn;
	}
	public ResultSet executeQuery(String sql){
		conn=getConnection();
		 try {
			stmt=conn.createStatement();
			rs=stmt.executeQuery(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 return rs;
	}
	public int executeUpdate(String sql){
		conn=getConnection();
		int flag=0;
		 try {
			stmt=conn.createStatement();
			flag=stmt.executeUpdate(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 return flag;
	}
	public void close(){
		if(rs!=null)
		try {
			rs.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(stmt!=null) 
		try {
			stmt.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(conn!=null)
		try {
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}

