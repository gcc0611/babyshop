package cn.xyafu.service;

import java.sql.SQLException;
import java.util.List;

import cn.xyafu.dao.ProductDao;
import cn.xyafu.form.Product;


public class ProductService {
    ProductDao pd=new ProductDao();
	public List<Product> findTodaybuy() {
		// TODO Auto-generated method stub
		try {
			return pd.findTodaybuy();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	public List<Product> findRandom() {
		// TODO Auto-generated method stub
		try {
			return pd.findRandom();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	public List<Product> findFenpage(int beginp, int psize) {
		// TODO Auto-generated method stub
		try {
			return pd.findFenpage(beginp,psize);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	public int allProducttotal() {
		// TODO Auto-generated method stub
		return pd.allProducttotal();
	}
	public Product findById(String id) {
		// TODO Auto-generated method stub
		try {
			return pd.findById(id);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	public List<Product> findTgou() {
		// TODO Auto-generated method stub
		try {
			return pd.findTgou();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	public List<Product> findTm() {
		// TODO Auto-generated method stub
		try {
			return pd.findTm();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	public List<Product> findRexiao() {
		// TODO Auto-generated method stub
		try {
			return pd.findRexiao();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

}
