package cn.xyafu.service;

import java.sql.SQLException;
import java.util.List;

import cn.xyafu.dao.TypeDao;
import cn.xyafu.form.Product;
import cn.xyafu.form.Types;


public class TypeService {
   TypeDao td=new TypeDao();
	public List<Types> findAllType() {
		// TODO Auto-generated method stub
		try {
			return td.findAllType();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	public List<Product> findTid(String id) {
		// TODO Auto-generated method stub
		try {
			return td.findTid(id);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

}
