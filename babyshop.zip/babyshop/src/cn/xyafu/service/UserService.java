package cn.xyafu.service;

import cn.xyafu.dao.UserDao;
import cn.xyafu.form.User;

public class UserService {
    UserDao ud=new UserDao();
	public User fingByName(String loginname) {
		// TODO Auto-generated method stub
		return ud.findByname(loginname);
	}
	public int addUser(User user) {
		// TODO Auto-generated method stub
		return ud.addUser(user);
	}

}
