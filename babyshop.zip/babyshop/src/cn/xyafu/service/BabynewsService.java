package cn.xyafu.service;

import java.sql.SQLException;
import java.util.List;

import cn.xyafu.dao.BabynewsDao;
import cn.xyafu.form.Babynews;

public class BabynewsService {
    BabynewsDao bd=new BabynewsDao();
	public List<Babynews> findBynews() {
		// TODO Auto-generated method stub
		try {
			return bd.findBynews();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

}
