package cn.xyafu.filter;

import java.io.IOException;
import java.io.UnsupportedEncodingException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import javax.servlet.http.HttpServletResponse;



public class EncondingFilter  implements Filter{
	public void destroy() {
		// TODO Auto-generated method stub
		
	}
	public void doFilter(ServletRequest arg0, ServletResponse arg1,
			FilterChain chain) throws IOException, ServletException {
		// TODO Auto-generated method stub
		   HttpServletRequest request=(HttpServletRequest) arg0;
		   HttpServletResponse  response=(HttpServletResponse) arg1;
		   response.setCharacterEncoding("utf-8");
			request.setCharacterEncoding("utf-8");
		   chain.doFilter(new MyRequest(request), response);
	}

	public void init(FilterConfig arg0) throws ServletException {
		// TODO Auto-generated method stub
		
	}
class MyRequest extends HttpServletRequestWrapper{
   private HttpServletRequest request;
	public MyRequest(HttpServletRequest request) {
		super(request);
		this.request=request;
		// TODO Auto-generated constructor stub
	}
	public String getParameter(String name){
		String value=super.getParameter(name);
		if (value!=null)
		try {
			if (request.getMethod().equalsIgnoreCase("get"))
			value=new String(value.getBytes("ISO-8859-1"),"utf-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return value;
	}
	
	//��дgetParameterValues()����
	@Override
	public String[] getParameterValues(String name) {
		String[] strs=super.getParameterValues(name);
		if (strs!=null)
		if (request.getMethod().equalsIgnoreCase("get"))
		for(int i=0;i<strs.length;i++){
			try {
				strs[i]=new String(strs[i].getBytes("ISO-8859-1"),"utf-8");
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return strs;
	}
   }
}

